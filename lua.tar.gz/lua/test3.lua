print(tostring(10) == "10")		-->true
print(10 .. "" == "10")			-->true
