local i = 0
f = loadstring("i = i + 1")
g = function ()
	i = i + 1 
end
