n = io.read()
assert(tonumber(n), "invalid input: " ..n.. "is not a number")
