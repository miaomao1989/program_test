print "enter your expression:"
local l = io.read()
local func = assert(load("return" .. l)) 
print("the value of your expression is " .. func())
