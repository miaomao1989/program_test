local path = "/usr/local/lua/lib/libluasocket.so"
local f = loadlib(path, "luaopen_socket")


local path = "/usr/local/lua/lib/libluasocket.so"
-- or path = "C:\\windows\\luasocket.dll"
local f = assert(loadlib(path, "luaopen_socket"))

f()		-- actually open the library

