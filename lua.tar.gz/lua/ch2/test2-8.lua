x = io.read("input value for x")
y = io.read("input value for y")

max = ( x > y ) and x or y

print(" the max between x and y is " .. max)
