do 
	local a2 = 2*a
	local d = (b^2 - 4*a*c)^(1/2)
	x1 = (-b + d)/a2
	x2 = (-b - d)/a2
end

print(x1, x2)
