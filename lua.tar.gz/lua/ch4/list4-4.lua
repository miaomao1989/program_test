do
	x = 10
	goto L1

	do 
		::L1::
		print(x)
	end
end
