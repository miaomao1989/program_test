Entry{
	"Donald E. Knuth",
	"Literate Programming",
	"CSLI",
	1992
}

Entry{
	"Jon Bentley",
	"More Programming Pearls",
	"Addison-Wesley",
	1990
}

