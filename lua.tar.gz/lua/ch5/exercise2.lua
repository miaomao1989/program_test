function unpack (array)
	print(table.unpack(array))
end
